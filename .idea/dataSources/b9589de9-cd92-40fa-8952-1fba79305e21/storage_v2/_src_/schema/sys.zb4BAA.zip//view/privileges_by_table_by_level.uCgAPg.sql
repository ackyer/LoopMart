create definer = `mariadb.sys`@localhost view privileges_by_table_by_level as
select `t`.`TABLE_SCHEMA`       AS `TABLE_SCHEMA`,
       `t`.`TABLE_NAME`         AS `TABLE_NAME`,
       `privs`.`GRANTEE`        AS `GRANTEE`,
       `privs`.`PRIVILEGE_TYPE` AS `PRIVILEGE`,
       `privs`.`LEVEL`          AS `LEVEL`
from (`information_schema`.`tables` `t` join (select NULL                                                    AS `TABLE_SCHEMA`,
                                                     NULL                                                    AS `TABLE_NAME`,
                                                     `information_schema`.`user_privileges`.`GRANTEE`        AS `GRANTEE`,
                                                     `information_schema`.`user_privileges`.`PRIVILEGE_TYPE` AS `PRIVILEGE_TYPE`,
                                                     'GLOBAL'                                                AS `LEVEL`
                                              from `information_schema`.`user_privileges`
                                              union
                                              select `information_schema`.`schema_privileges`.`TABLE_SCHEMA`   AS `TABLE_SCHEMA`,
                                                     NULL                                                      AS `TABLE_NAME`,
                                                     `information_schema`.`schema_privileges`.`GRANTEE`        AS `GRANTEE`,
                                                     `information_schema`.`schema_privileges`.`PRIVILEGE_TYPE` AS `PRIVILEGE_TYPE`,
                                                     'SCHEMA'                                                  AS `LEVEL`
                                              from `information_schema`.`schema_privileges`
                                              union
                                              select `information_schema`.`table_privileges`.`TABLE_SCHEMA`   AS `TABLE_SCHEMA`,
                                                     `information_schema`.`table_privileges`.`TABLE_NAME`     AS `TABLE_NAME`,
                                                     `information_schema`.`table_privileges`.`GRANTEE`        AS `GRANTEE`,
                                                     `information_schema`.`table_privileges`.`PRIVILEGE_TYPE` AS `PRIVILEGE_TYPE`,
                                                     'TABLE'                                                  AS `LEVEL`
                                              from `information_schema`.`table_privileges`) `privs`
      on ((`t`.`TABLE_SCHEMA` = `privs`.`TABLE_SCHEMA` or `privs`.`TABLE_SCHEMA` is null) and
          (`t`.`TABLE_NAME` = `privs`.`TABLE_NAME` or `privs`.`TABLE_NAME` is null) and `privs`.`PRIVILEGE_TYPE` in
                                                                                        ('SELECT', 'INSERT', 'UPDATE',
                                                                                         'DELETE', 'CREATE', 'ALTER',
                                                                                         'DROP', 'INDEX', 'REFERENCES',
                                                                                         'TRIGGER', 'GRANT OPTION',
                                                                                         'SHOW VIEW',
                                                                                         'DELETE HISTORY')))
where `t`.`TABLE_SCHEMA` not in ('sys', 'mysql', 'information_schema', 'performance_schema');

