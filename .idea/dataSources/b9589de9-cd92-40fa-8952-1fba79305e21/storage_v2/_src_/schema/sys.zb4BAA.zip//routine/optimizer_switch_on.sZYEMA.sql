create
    definer = `mariadb.sys`@localhost procedure optimizer_switch_on()
    comment 'return @@optimizer_switch options that are on'
    sql security invoker
BEGIN
  call optimizer_switch_choice("on");
END;

